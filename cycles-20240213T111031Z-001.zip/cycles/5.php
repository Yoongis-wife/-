<?php
$width  = 8;
$height = 8;
$table = '<table border="1">';

for ($tr=1; $tr<=$width; $tr++){
    $table .= '<tr>';
    for ($td=1; $td<=$height; $td++){
        if (($tr%2!=0 && $td%2==0)||($tr%2==0 && $td%2!=0)){
            $table .= '<td style="background-color:black;width:30px;height:30px"></td>'; 
        }
        else
        {
            $table .= '<td style="background-color:white;width:30px;height:30px"></td>';
        }
    }
    $table .= '</tr>';
}

$table .= '</table>';
echo $table; 
?>