<?php 
$arr=array();
$j=1;
for($i=0;$i<50;$i++)
{
    if(($j % 3 == 0) && ($j % 5 != 0))
    {
        $arr[$i]="Fizz";
    }
    else if(($j % 3 != 0) && ($j%5==0))
    {
        $arr[$i]="Buzz";
    }
    else if (($j%3==0) && ($j%5==0))
    {
        $arr[$i]="FizzBuzz";
    }
    else 
    {
        $arr[$i]=$j;
    }
    $j++;
}
echo implode(" ", $arr);
?>