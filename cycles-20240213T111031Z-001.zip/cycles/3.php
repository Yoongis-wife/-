<?php
$cols=rand(1,10);
$rows=rand(1,10); 
$table = '<table border="1">';

for ($tr=1; $tr<=$rows; $tr++){
    $table .= '<tr>';
    for ($td=1; $td<=$cols; $td++){
        if ($tr===1 or $td===1){
            $table .= '<th style="color:white;background-color:purple;font-weight:700">'. $tr*$td .'</th>'; 
        }else{
            $table .= '<td>'. $tr*$td .'</td>';
        }
    }
    $table .= '</tr>';
}

$table .= '</table>';
echo $table; 
?>