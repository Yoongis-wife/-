<?php 
$count=$_GET['coun'];
$i=1;
$j=0;
$array=array();
while ($j<$count)
{
    $array[$j]=$i;
    $j++;
    $i+=3;
}
echo implode(" ",$array);
?>