<?php
$width  = 6;
$height = 5;
$table = '<table border="1";cellpadding=3px;cellspacing=0px>';

for ($tr=1; $tr<=$width; $tr++){
    $table .= '<tr>';
    for ($td=1; $td<=$height; $td++)
    {
        $table .= '<td style="background-color:white;">'.$tr.' * '.$td.' = '.$tr*$td.'</td>'; 
    }
    $table .= '</tr>';
}

$table .= '</table>';
echo $table; 
?>