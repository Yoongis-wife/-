﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Форма_2
{
    public partial class Form1 : Form
    {
        class String
        {
            private string Stroka;
            public void Str(string stroka)
            {
                if (stroka.Length > 10) Stroka = "Слишком длинная строка";
                else this.Stroka =stroka;
                MessageBox.Show(Stroka);
            }
            public void Strr()
            {
                Stroka ="Пусто";
                MessageBox.Show(Stroka);
            }
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String string1= new String();
            if (textBox1.Text == "") { string1.Strr(); }
            else string1.Str(textBox1.Text);
           
        }
    }
}
