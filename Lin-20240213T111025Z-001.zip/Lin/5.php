<?php 
$num=$_GET['num'];
preg_match_all('/\d/', $num, $matches);
if(count($matches)<4)
{
   echo array_product($matches[0]); 
}
else{
    echo"Введите 4 значное число";
}
 

?>