<?php
$name=$_POST['name'];
$lastname=$_POST['lastname'];
$mail=$_POST['mail'];
$comment=$_POST['comment'];

if (isset($_POST)) {
    print("Ваше имя " . $_POST['name']);
    print("<br>Ваша фамилия " . $_POST['lastname']);
    print("<br>Ваш e-mail " . $_POST['mail']);
    print("<br>Это комментарий ".$_POST['comment']);
    print("<br>Щелкните <a href=''>здесь</a>, чтобы увидеть персональное приветствие!");
}

?>