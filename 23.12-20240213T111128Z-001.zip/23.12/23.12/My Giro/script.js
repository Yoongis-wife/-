var slad= document.getElementById('slad');

slad.onclick=function()
{
    if(document.getElementById('n_0').style.display!='none' )
    {
        
        showOneHideOthers("n_", 3, 1); 
    }
    else if(document.getElementById('n_1').style.display!='none' )
    {
        showOneHideOthers("n_", 3, 2); 
    }
    else if(document.getElementById('n_2').style.display!='none')
    {
        showOneHideOthers("n_", 3, 0); 
    }
    function showOneHideOthers(base, len, numToShow) {
    
        for (var i = 0; i < len; i++) {
            
            if (i != numToShow) {
               
                document.getElementById(base+i).style.display = "none";
            }
        }
        document.getElementById(base+numToShow).style.display = "flex";
    }
     
}

