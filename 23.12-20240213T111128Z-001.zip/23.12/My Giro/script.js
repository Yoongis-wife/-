var slad= document.getElementById('slad');

slad.onclick=function()
{
    if(document.getElementById('n_0').style.display!='none' )
    {
        
        showOneHideOthers("n_", 3, 1); 
    }
    else if(document.getElementById('n_1').style.display!='none' )
    {
        showOneHideOthers("n_", 3, 2); 
    }
    else if(document.getElementById('n_2').style.display!='none')
    {
        showOneHideOthers("n_", 3, 0); 
    }
    function showOneHideOthers(base, len, numToShow) {
    
        for (var i = 0; i < len; i++) {
            
            if (i != numToShow) {
               
                document.getElementById(base+i).style.display = "none";
            }
        }
        document.getElementById(base+numToShow).style.display = "flex";
    }
     
}
document.querySelector('#up').onclick = () => {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }
  filterSelection("all");
function filterSelection(c) {
  var x, i;
  x = document.getElementsByClassName("card_item");
  if (c == "all") c = "";
  // Добавить класс "show" (display:block) к отфильтрованным элементам и удалите класс "show" из элементов, которые не выбраны
  for (i = 0; i < x.length; i++) {
    w3RemoveClass(x[i], "show");
    if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "show");
  }
}

// Показать отфильтрованные элементы
function w3AddClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    if (arr1.indexOf(arr2[i]) == -1) {
      element.className += " " + arr2[i];
    }
  }
}

// Скрыть элементы, которые не выбраны
function w3RemoveClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    while (arr1.indexOf(arr2[i]) > -1) {
      arr1.splice(arr1.indexOf(arr2[i]), 1);
    }
  }
  element.className = arr1.join(" ");
}

// Добавить активный класс к текущей кнопке управления (выделите ее)
var btnContainer = document.getElementById("buttons");
var btns = btnContainer.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}
document.getElementById('sub').addEventListener('click',function()
{
    
    var plus=0;
    Mail();
    Name();
    if (plus==2)
    {
        alert('Форма отправлена');
    }
    function Mail() {
    var re = /^[\w-\.]+@[\w-]+\.[a-z]{2,4}$/i;
    var mail = document.getElementById('mail').value;
    var valid = re.test(mail);
    if (valid)
    {
        plus++;
    } 
    else alert('Адрес электронной почты введен неправильно!');
}
function Name()
{
    var re = /[а-яА-ЯЁё]/;
    var mail = document.getElementById('nname').value;
    var valid = re.test(mail);
    if (valid) plus++;
    else alert('Имя введено неправильно!');
}
})
