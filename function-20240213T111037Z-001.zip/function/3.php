<?php 
$arr=array();
$count=rand(1,15);
echo "Исходный массив<br>";
for($i=0;$i<$count;$i++)
{
    $arr[$i]=rand(1,25);
    echo " ".$arr[$i];
}
echo"<br>";
echo "Количество элементов в массиве ".$count."<br>";
massiv($arr);
function massiv($array)
{
    $max=-100;
    $index=0;
    for($i=0;$i<count($array);$i++)
    {
        if($max<$array[$i])
        {
            $max=$array[$i];
            $index=$i;
        }
    }
    echo "Максимальный элемент массива ".$max;
    echo "<br>Его индекс равен ".$index;
}

?>