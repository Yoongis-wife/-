<?php
 echo "Написать функцию, которая вычисляет значения x=sin2(a) и y=cos2(a). Напечатать таблицу значений от –π до π с шагом π/4.";

 function paint()
 {
 for($i=-M_PI;$i<=M_PI;$i+=M_PI/4)
 {
     $x=sin($i)**2;
     $y=cos($i)**2;
     echo '<tr>';
     echo '<td>'.number_format($i,2).'</td>';
     echo '<td>'.number_format($x,2).'</td>';
     echo '<td>'.number_format($y,2).'</td>';
     echo '<tr>';
 }
 }
 echo '<table border="1"; cellpadding="1px"; cellspacing="0px">';
 echo '<tr';
 echo '<td> π </td>';
 echo '<td> x </td>';
 echo '<td>  y </td>';
 echo '<tr>';
 paint();
echo '</table>';
?>