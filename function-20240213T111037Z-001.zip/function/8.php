<?php 
echo "Задайте двумерный массив, содержащий сведения о студентах группы (№пп, ФИО, возраст, пол). 
Создайте скрипт, выводящий все элементы массива в виде HTML–таблицы (используйте для этого цикл foreach):
    № пп
    ФИО
    возраст пол
    
    а) Создайте функцию поиска в массиве студентов самого молодого студента.
    б) Реализуйте функцию поиска в массиве информации о студенте с заданной фамилией.
    <br>";
    $students=array(
        array(1,"Иванова Дарья Ивановна",17,"женский"),
        array(2,"Пупкин Пупок Пупкович",18,"мужской"),
        array(3,"Петров Петя Петрович",19,"мужской")
        );
        //молодой
        function younger($students)
        {
        $min=1000;
        $youngAge=$students[1][2];
        $youngStudent=$students[1];
        foreach($students as $student)
        {
        if($student[2]<$min)
        {
           $min= $student[2];
            $youngAge=$student[2];
            $youngStudent=$student;
        }
        }
        return $youngStudent;
        }
//фамилия
function surname($students, $surname)
{
    foreach($students as $student)
    {
        if(strpos($student[1], $surname)!==false)//strpos разбивает 3 слова и смотрит есть ли нужная подстрока
        {
            return $student;
        }
    }
    return null;
}
$youngStudent=younger($students);
echo "самый молодой студент: ".$youngStudent[1].", возраст".
$youngStudent[2]."<br>";

$surname="Пупкин";
$student=surname($students,$surname);
if($student!=null)
{
    echo "студент с фамилией ".$surname.": ".$student[1].", возраст= ".$student[2]."<br>";
}
else{
    echo "студент с фамилией ".$surname." не найден"."<br>"; 
}        

?>