﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Форма_3
{
    public partial class Form1 : Form
    {
        class Triangle
        {
            public double St_A;
            public double St_B;
            public double St_C;

            public double Y_A;
            public double Y_B;
            public double Y_C;

            public string Vig;

            public void Pravilo(double a, double b, double c)
            {
                St_A = a;
                St_B = b;
                St_C = c;
                if (((a + b) > c) && ((a+c)>b) && ((b+c)>a)) MessageBox.Show("Треугольник существует");
                else MessageBox.Show("Такого треугольника нет");
            }

            public void Corner(double a, double b, double c)
            {
                 double ya = (Math.Acos((Math.Pow(b, 2) + Math.Pow(c, 2) - Math.Pow(a, 2)) / (2 * b * c))) * (180 / Math.PI);
                 double yb = (Math.Acos((Math.Pow(a, 2) + Math.Pow(c, 2) - Math.Pow(b, 2)) / (2 * a * c))) * (180 / Math.PI);
                 double yc = (Math.Acos((Math.Pow(b, 2) + Math.Pow(a, 2) - Math.Pow(c, 2)) / (2 * b * a))) * (180 / Math.PI);
               
                Y_A=ya;
                Y_B=yb;
                Y_C=yc;

                if (Y_A>90 || Y_B>90 || Y_C>90) Vig="Треугольник тупоугольный";
                else if (Y_A==90 || Y_B==90 || Y_C==90) Vig="Треугольник прямоугольный";
                else if (Y_A<90 && Y_B<90 && Y_C<90) Vig="Треугольник остроугольный";
                else if (Y_A==Y_B || Y_B==Y_C || Y_A==Y_C) Vig="Треугольник равнобедренный";
                else if (St_A==St_B && St_B==St_C) Vig="Треугольник равносторонний";
            }

            public void Write()
            {
                MessageBox.Show("Все найденные значения:"+"1. Стороны: "+St_A+", "+St_B+", "+St_C+";"+String.Format("угол A: {0:F0}; угол B: {1:F0}; угол C: {2:F0} ", Y_A, Y_B, Y_C)+Vig);
            }

        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Triangle triangle1 = new Triangle();
            triangle1.Pravilo(Convert.ToDouble(textBox1.Text), Convert.ToDouble(textBox2.Text), Convert.ToDouble(textBox3.Text));
            triangle1.Corner(Convert.ToDouble(textBox1.Text), Convert.ToDouble(textBox2.Text), Convert.ToDouble(textBox3.Text));
            triangle1.Write();

        }
    }
}
