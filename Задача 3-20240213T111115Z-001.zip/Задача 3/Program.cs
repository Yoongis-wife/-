﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            int i = 1;
            int n = 1;
            do
            {
                Console.WriteLine("Введите "+i+" член последовательности");
                n=int.Parse(Console.ReadLine());
                i++;
                if (n==13)
                {
                    Console.WriteLine("Число 13 найдено");
                    break;
                }
                else  
                Console.WriteLine("Числа 13 нет.");
            }
            while (i<=10);
            
            Console.ReadKey();
        }
    }
}
