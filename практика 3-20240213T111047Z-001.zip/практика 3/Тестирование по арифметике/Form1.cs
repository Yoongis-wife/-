﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Тестирование_по_арифметике
{
    public partial class Form1 : Form
    {
        Timer timer=new Timer();
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        public int n, n1, n2, n3, n4, n5,n6,n7;

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label19.Text=DateTime.Now.ToLongTimeString();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            button2.Enabled=!(textBox1.Text.Length<1 && textBox2.Text.Length<1 && textBox3.Text.Length<1 && textBox4.Text.Length<1 );
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            Random rnd = new Random();
            n=Convert.ToInt32(label1.Text = Convert.ToString(rnd.Next(0,100)));
            n1= Convert.ToInt32(label2.Text = Convert.ToString(rnd.Next(0,100)));
            n2= Convert.ToInt32(label3.Text = Convert.ToString(rnd.Next(0,50)));
            int x = Convert.ToInt32(label3.Text);
            n3= Convert.ToInt32(label9.Text = Convert.ToString(rnd.Next(1, 10)));
            n4= Convert.ToInt32(label10.Text = Convert.ToString(rnd.Next(1, 10)));
            n5= Convert.ToInt32(label11.Text = Convert.ToString(rnd.Next(1, 10)));
            int y = Convert.ToInt32(label11.Text);
            n6=Convert.ToInt32(label12.Text = Convert.ToString(y));
            n7=Convert.ToInt32(label4.Text = Convert.ToString(x*y));
        }
        private void button3_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text = "";
            label3.Text = "";
            label4.Text = "";
            label9.Text = "";
            label10.Text = "";
            label11.Text = "";
            label12.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            label21.Text = "";
            label22.Text = "";
            label23.Text = "";
            label24.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int i, i1, i2, i3;
            i=(n+n3);
            i1=(n1-n4);
            i2=(n2*n5);
            i3=(n7/n6);
            label21.Text=Convert.ToString(i);
            label22.Text=Convert.ToString(i1);
            label23.Text=Convert.ToString(i2);
            label24.Text=Convert.ToString(i3);
            int s1=Convert.ToInt32(textBox1.Text);
            int s2 = Convert.ToInt32(textBox2.Text);
            int s3 = Convert.ToInt32(textBox3.Text);
            int s4 = Convert.ToInt32(textBox4.Text);
            int mark = 1;
            if(s1==i || s2==i1 || s3==i2 || s4==i3)
            {
                mark=2;
                label20.Text=Convert.ToString(mark);
            }
            else if(s1==i && s2==i1 || s1==i && s3==i2 || s1==i && s4==i3 || s2==i1 && s3==i2 || s2==i1 && s4==i3 || s3==i2 && s4==i3)
            {
                mark=3;
                label20.Text=Convert.ToString(mark);
            }
            else if(s1==i && s2==i1 && s3==i2 || s1==i && s2==i1 && s4==i3 || s2==i1 && s3==i2 && s4==i3 || s1==i && s3==i2 && s4==i3 )
            {
                mark=4;
                label20.Text=Convert.ToString(mark);
            }
            else if(s1==i && s2==i1 && s3==i2 && s4==i3 )
            {
                mark=5;
                label20.Text=Convert.ToString(mark);
            };
           
            timer1.Stop();
        }
    }
}
