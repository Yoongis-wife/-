﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Угадай_число
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }
        public int ch;
        public int x;
        private void button1_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            x = Convert.ToInt32(textBox1.Text);
            ch = rnd.Next(0, x);
            textBox2.Focus();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            button1.Enabled = !(textBox1.Text.Length < 1);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            button2.Enabled = !(textBox2.Text.Length < 1);
        }
        int y = 0;
        private void button2_Click(object sender, EventArgs e)
        {
            int pop = Convert.ToInt32(textBox2.Text);
            y++;
            if (ch == pop)
            {
                textBox3.Text = "попал";
                textBox4.Text = Convert.ToString(y);
            }
            else if (ch > pop)
            {
                textBox3.Text = "Недолет";
                textBox4.Text = Convert.ToString(y);
            }
            else if( ch < pop )
            {
                textBox3.Text = "перелет";
                textBox4.Text = Convert.ToString(y);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;

            if (!Char.IsDigit(number))
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;

            if (!Char.IsDigit(number))
            {
                e.Handled = true;
            }
        }
    }
}
