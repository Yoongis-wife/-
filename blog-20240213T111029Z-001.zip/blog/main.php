<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php
     $conn = new mysqli("localhost", "root", "", "Nikiforova"); 
     if($conn->connect_error){
         die("Ошибка: " . $conn->connect_error);
     }
     ?>
    <style>
        .post
        {
            width: 300px;
            height: 400px;
            border: 1px solid black;
            border-radius: 5px;
            margin-bottom: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .post h2 
        {
            font-size: 20px;
            width: 280px;
            white-space: no-wrap;
            height: 110px;
            margin-top: 20px;
        }
        .post img 
        {
            width: 270px;
            height: 200px;
            margin-top: -10px;
        }
        .post form input
        {
            width: 80px;
            height: 20px;
            border: none;
            border-radius: 5px;
            background-color: #B56AFF;
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            color: black;
           text-align: center;
           margin-left: 180px;
          margin-top: 15px;
        }
        .container
        {
            display: flex;
            margin-top: 30px;
            margin-left: 20px;
            margin-right: 20px;
            margin-bottom: 20px;
            flex-wrap: wrap;
            flex-direction: row;
            justify-content: space-between
        }
    </style>
</head>
<body>
    <?php
    include "pages/header.php";
    ?>
    <div class='container'>
    <?php 
    $sql = "SELECT * FROM posts";
    if($result = $conn->query($sql)){ 
        
        while($row =$result->fetch_assoc()){
        echo "<div class='post'>";
        echo "<form action='post.php' method='get'>
            <input type='hidden' name='id_post' value='" . $row["id"] . "' />
            <input type='submit' value='Просмотр' class='button'></form></td>";
          echo '<h2> '.$row['name_post'] ."</h2>";
          echo '<img src="'.$row['img'].'">';
          echo "</div>";
        }
    } else{
        echo "Ошибка: " . $conn->error;
    }
    ?>
    </div>
    <?php
    include "pages/footer.php";
    ?>
</body>
</html>
