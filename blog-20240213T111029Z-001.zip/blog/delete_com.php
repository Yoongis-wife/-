<?php
    include "pages/header.php";
    ?>
<?php
if(isset($_POST["id"]))
{
    $conn = new mysqli("localhost", "root", "", "Nikiforova");
    if($conn->connect_error){
        die("Ошибка: " . $conn->connect_error);
    }
    $id = $conn->real_escape_string($_POST["id"]);
    $sql = "DELETE FROM comment WHERE id = '$id'";
    if($conn->query($sql)){
         
       echo 'gff';
    }
    else{
        echo "Ошибка: " . $conn->error;
    }
    $conn->close();  
}
?>