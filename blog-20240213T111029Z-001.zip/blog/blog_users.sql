-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Фев 05 2024 г., 15:38
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `Nikiforova`
--

-- --------------------------------------------------------

--
-- Структура таблицы `blog_users`
--

CREATE TABLE `blog_users` (
  `id` int NOT NULL,
  `login` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` int NOT NULL,
  `name` varchar(30) NOT NULL,
  `surname` varchar(30) NOT NULL,
  `lastname` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `phone_number` bigint DEFAULT NULL,
  `email` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `id_status_users` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `blog_users`
--

INSERT INTO `blog_users` (`id`, `login`, `password`, `name`, `surname`, `lastname`, `phone_number`, `email`, `id_status_users`) VALUES
(1, 'big_admin', 696969, 'Алена', 'Никифорова', 'Андреевна', 89563457887, 'nikiforovaalena329@gmail.com', 1),
(2, 'yoongiswife', 9031993, 'Маша', 'Иванова', 'Ивановна', 89563214558, 'yooni2025@gmail.com', 2),
(3, 'namjin77', 1234567, 'Иван', 'Иванов', 'Иванович', 89532456723, 'jjin30@gmail.com', 2),
(4, 'popa', 123, 'Маша', 'Иванова', 'Ивановна', 8964356465, 'fdgdh@mail.com', 2);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `blog_users`
--
ALTER TABLE `blog_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status` (`id_status_users`),
  ADD KEY `status_users` (`id_status_users`),
  ADD KEY `id_status_users` (`id_status_users`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `blog_users`
--
ALTER TABLE `blog_users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `blog_users`
--
ALTER TABLE `blog_users`
  ADD CONSTRAINT `blog_users_ibfk_1` FOREIGN KEY (`id_status_users`) REFERENCES `status_users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
