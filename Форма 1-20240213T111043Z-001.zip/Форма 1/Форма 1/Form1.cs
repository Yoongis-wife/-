﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Форма_1
{
    public partial class Form1 : Form
    {
        class Primer
        {
            public int A { get; set; }
            public int B { get; set; }
          
            public Primer()
            {
                MessageBox.Show("Сумма равна нулю");
            }
            public Primer(int a)
            {
                A = a;
                MessageBox.Show("Сумма равна "+A);
            }
            public Primer(int a, int b)
            {
                A = a;
                B = b;
                MessageBox.Show("Сумма равна " + (A+B));
            }
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
           Primer prime3 = new Primer(Convert.ToInt32(textBox1.Text), Convert.ToInt32(textBox2.Text)); 
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Primer primer1 = new Primer();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Primer primer2 = new Primer(Convert.ToInt32(textBox1.Text));
        }
    }
}
