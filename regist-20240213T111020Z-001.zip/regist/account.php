<?php
 $conn = new mysqli("localhost", "root", "", "Nikiforova"); 
 if($conn->connect_error){
     die("Ошибка: " . $conn->connect_error);
 }
 session_start();
 $id = $_SESSION['id'];
 $query = "SELECT * FROM user WHERE id='$id'";
 $result = mysqli_query($conn, $query);
 $user = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="" method="POST">
<input name="name" value="<?php $user['name'] ?>">
<input name="surname" value="<?php $user['surname'] ?>">
<input type="submit" name="submit">
</form>
<?php
if (!empty($_POST['submit'])) {
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $query = "UPDATE user SET name='$name', surname='$surname' WHERE id=$id";
    mysqli_query($conn, $query);
    }
?>
</body>
</html>