<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="proverka.php" method="POST">
<input name="login">
<input name="password" type="password">
<input type="submit">
</form>
<form action="account.php">
    <input type="submit">
</form>
<form action="logout.php">
    <input type="submit" value="Выйти из аккаунта">
</form>
<form action="changepassword.php">
    <input type="submit" value="Сменить пароль">
</form>
<form action="delete.php">
    <input type="submit" value="удалить">
</form>
<form action="admin.php">
    <input type="submit" value="Страница для админа">
</form>

    <?php
    $conn = new mysqli("localhost", "root", "", "Nikiforova"); 
    if($conn->connect_error){
        die("Ошибка: " . $conn->connect_error);
    }
    if (!empty($_POST['password']) and !empty($_POST['login'])) 
    {
        $login = $_POST['login'];
        $query = "SELECT * FROM user WHERE login='$login'"; // получаем юзера по логину
        $result = mysqli_query($conn, $query);
        $user = mysqli_fetch_assoc($result);

        if (!empty($user)) {
            session_start();
        $hash = $user['password']; 
       
        if (password_verify($_POST['password'], $hash)) {
            $_SESSION['auth'] = true;
            $_SESSION['id'] = $user['id'];
            $_SESSION['status'] = $user['status'];
            echo "Хорошо";
        }
        else {  
            echo "Не подошел пароль";
        // пароль не подошел, выведем сообщение
        }
        } else {
            echo "Поль-ля с таким логином нет";
        // пользователя с таким логином нет, выведем сообщение
        }
    }
    ?>
</body>
</html>