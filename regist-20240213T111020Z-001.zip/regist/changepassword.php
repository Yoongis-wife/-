<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="" method="POST">
<input type="password" name="old_password">
<input type="password" name="new_password">
<input type="password" name="new_password_confirm">
<input type="submit" name="submit">
</form>
<?php
 $conn = new mysqli("localhost", "root", "", "Nikiforova"); 
 if($conn->connect_error){
     die("Ошибка: " . $conn->connect_error);
 }
 session_start();
$id = $_SESSION['id']; // id юзера из сессии
$query = "SELECT * FROM user WHERE id='$id'";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);
$hash = $user['password']; // соленый пароль из БД
$oldPassword = $_POST['old_password'];
$newPassword = $_POST['new_password'];
if (password_verify($oldPassword, $hash)) {
    $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);
    $query = "UPDATE user SET password='$newPasswordHash' WHERE id='$id'";
    mysqli_query($conn, $query);
    } else {
    echo "старый пароль введен неверно";
    }
?>
</body>
</html>