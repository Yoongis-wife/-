<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="" method="POST">
<input name="login">
<input name="password" type="password">
<input type="password" name="confirm">
<input type="name" name="name">
<input type="text" name="surname">
<input type="text" name="status">
<input type="submit">
</form>

<?php
 $conn = new mysqli("localhost", "root", "", "Nikiforova"); 
 if($conn->connect_error){
    die("Ошибка: " . $conn->connect_error);
}
session_start();
if (!empty($_POST['login']) and !empty($_POST['password']) and !empty($_POST['confirm'])) {
    if ($_POST['password'] == $_POST['confirm']) {
       
$login = $_POST['login'];

$query = "SELECT * FROM user WHERE login='$login'";
$user = mysqli_fetch_assoc(mysqli_query($conn, $query));

if (empty($user)) { 
  $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$name=$_POST['name'];
$surname=$_POST['surname'];
$status=$_POST['status'];  
$querym = "INSERT INTO 'user' SET login='$login', password='$password', name='$name', surname='$surname', status_user='$status'";
mysqli_query($conn, $querym);
$_SESSION['status']=$status;  

$_SESSION['auth'] = true;
$_SESSION['id'] = $user['id'];
}
else{
    echo "Логин занят";
}
} else {
    echo "Пароль и его подтверждение не совпадают";
}
}
?>
<form action="proverka.php">
    <input type="submit" value="След страница">
</form>

</body>
</html>