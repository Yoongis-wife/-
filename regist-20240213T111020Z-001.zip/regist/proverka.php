<?php
session_start();
if ($_SESSION['auth']==true): ?>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<p>текст только для авторизованного пользователя</p>
<form action="admin.php">
    <input type="submit" value="Страница для админа">
</form>
</body>
</html>
<?php else: ?>
<p>пожалуйста, авторизуйтесь</p>
<?php endif; ?>