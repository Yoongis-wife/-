<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="" method="POST">
<input  name="login">
<input type="password" name="password">
<input type="submit" name="submit">
</form>
<?php
$conn = new mysqli("localhost", "root", "", "Nikiforova"); 
if($conn->connect_error){
    die("Ошибка: " . $conn->connect_error);
}
session_start();
$id = $_SESSION['id'];
$query = "SELECT * FROM user WHERE id='$id'";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);
$hash = $user['password']; // соленый пароль из БД
// Проверяем соответствие хеша из базы введенному старому паролю
if (password_verify($_POST['password'], $hash)) {
    $query = "DELETE FROM user WHERE id='$id'";
    mysqli_query($conn, $query);
    } else {
    // пароль введен неверно, выведем сообщение
    }
    ?>
</body>
</html>