<?php
session_start();
$_SESSION['auth'] = null;
$_SESSION['id'] = null;
$_SESSION['status'] = null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="auth.php">
        <input type="submit" value="Назад">
    </form>
</body>
</html>