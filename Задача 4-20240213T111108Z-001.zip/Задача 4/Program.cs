﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            int a = 0;
            int b = 0;
            int n = 0;
            int i = 1;
            Console.WriteLine("Введите значение A ");
            a=int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение B ");
            b=int.Parse(Console.ReadLine());
            sum=a+b;
            do
            {
                Console.WriteLine("Введите "+i+" число");
                n=int.Parse(Console.ReadLine());      
                    if (n>a && n<b)
                    sum+=n;
                i++;
            }
            while(i<=7);
            Console.WriteLine("Сумма 7 чисел промежутка от {0} до {1} равна {2}", a,b,sum);
            Console.ReadLine();
        }
    }
}
