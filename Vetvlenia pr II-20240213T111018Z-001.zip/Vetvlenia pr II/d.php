
    <?php 
    $x=$_GET['x'];
    $y=$_GET['y'];
    $z=$_GET['z'];
    $max= -10000;
    if ($y>$max)
    {
        $max=$y;
    }
    if($z>$max)
    {
        $max=$z;
    }
    if($x>$max)
    {
        $max=$x;
    }
    echo "Максимальное число - " . $max;
    ?>

</body>
</html>