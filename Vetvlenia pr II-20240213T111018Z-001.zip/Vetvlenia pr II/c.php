
    <?php 
    $year=$_GET['year'];
    if($year<3000 && $year>900)
    {
    if(($year%100!=0 && $year%4==0) || $year%400==0)
    {
        echo"Високосный ";  
    }
    else
    {
        echo"Не високосный ";
    }
}
else{
    echo"Неправильные данные";
}
    ?>
