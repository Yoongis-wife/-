
    <?php 
    $month=$_GET['month'];
    if($month<3 || $month==12)
    {
        echo"зима ";   
    }
    else if($month>2 && $month<6)
    {
        echo"весна ";
    }
    else if($month>5 && $month<9)
    {
        echo"лето ";
    }
    else if($month>8 && $month<12)
    {
        echo"осень ";
    }
    else 
    {
        echo'Введите число от 1 до 12';
    }
    ?>