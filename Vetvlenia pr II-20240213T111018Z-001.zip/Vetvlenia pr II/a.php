
    <?php
    $day=$_GET['day'];
    if($day<11)
    {
        echo"1 декада ";
    }
    else if($day>10 && $day<21)
    {
        echo"2 декада ";
    }
    else if($day>20 && $day<32)
    {
        echo"3 декада ";
    }
    else{
        echo'Введите число от 1 до 31';
    }
    ?>
