﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1_Массив_переключателей
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            label2.Text = "Поздравляем, у вас хороший вкус! Вы выбрали Васильки" + radioButton3.Text;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            label2.Text="Поздравляем, у вас хороший вкус! Вы выбрали Розы"+radioButton1.Text;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            label2.Text = "Поздравляем, у вас хороший вкус! Вы выбрали Ландыши" + radioButton2.Text;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            label2.Text = "Поздравляем, у вас хороший вкус! Вы выбрали Орхидеи" + radioButton4.Text;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            label2.Text = "Поздравляем, у вас хороший вкус! Вы выбрали Ромашки" + radioButton5.Text;
        }
    }
}
