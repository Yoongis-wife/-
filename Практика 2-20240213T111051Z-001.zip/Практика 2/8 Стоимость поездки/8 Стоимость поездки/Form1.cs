﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _8_Стоимость_поездки
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label1.Text ="Расстояние (км):";
            label2.Text ="Цена бензина \n (руб/литр):";
            label3.Text="Потребление бензина \n (литр на 100 км):";
            label4.Text="                                                                      ";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text!=null )
            {
                button2.Enabled=true;
            }
           
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if ( textBox2.Text!=null)
            {
                button2.Enabled=true;
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (textBox3.Text!=null)
            {
                button2.Enabled=true;
            }
            if (textBox1.Text!=null && textBox2.Text!=null && textBox3.Text!=null)
            {
                button1.Enabled=true;
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;

            if (!Char.IsDigit(number))
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;

            if (!Char.IsDigit(number))
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;

            if (!Char.IsDigit(number))
            {
                e.Handled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int rast=Convert.ToInt32(textBox1.Text);
            int r=Convert.ToInt32(textBox2.Text);
            int ras=Convert.ToInt32(textBox3.Text);
            double st = (r*ras)*(rast/100);
            if(checkBox1.Checked==true)
            {
                st*=2;
            }
            label4.Text="Поездка на дачу обошлась в "+st.ToString("F2")+"р.";
        }
    }
}
