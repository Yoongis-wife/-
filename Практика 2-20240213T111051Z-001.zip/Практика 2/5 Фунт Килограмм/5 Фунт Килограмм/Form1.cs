﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _5_Фунт_Килограмм
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            BackColor = Color.Pink;
            label1.Font=new Font("Microsoft Sans Serif",12);
            label1.Text ="Введите вес в фунтах и щелкните на кнопке\n" +
                "Пересчет.Для отделения дробной части от це-\nлой, используйте запятую.";
            string st = textBox1.Text;
            if (st != null) { button1.Enabled = true; }
        }
        private void button1_Click(object sender, EventArgs e)
        {
           double s=Convert.ToInt32(textBox1.Text);
            double a=s*0.4095;
            label2.Font=new Font("Microsoft Sans Serif", 12);
            label2.Text=(Convert.ToString(s)+" ф - это "+a.ToString("F2")+" кг");
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;

            if (!Char.IsDigit(number))
            {
                e.Handled = true;
            }
        }
    }
}
