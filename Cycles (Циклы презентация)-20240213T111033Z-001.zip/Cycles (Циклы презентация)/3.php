<?php
$gift=1;
for($i=2;$i<90;$i++)
{
    $gift*=2;
    $gift+=$i;
    if($gift>100)
    {
        echo "Подарок превысит 100$ к ".$i ." дню рождения";
        break;
        
    }
}
?>