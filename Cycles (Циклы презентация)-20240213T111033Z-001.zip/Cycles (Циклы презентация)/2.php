<?php
$sum=0;
for($i=1;$i<101;$i++)
{
    if($i%7==0)
    {
        $sum+=$i;
    }
}
echo $sum;
?>