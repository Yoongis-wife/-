﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Игра
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            KartinkiVKvadrat();
        }
        Random r = new Random();
        List<string> kartinki = new List<string>()
        {
        "!", "!", "N", "N", ",", ",", "p", "p",
        "b", "b", "v", "v", "e", "e", "l", "l"
        };
        private void KartinkiVKvadrat()
        {
            foreach (Control control in tableLayoutPanel1.Controls)
            {
                Label icon = control as Label;
                if (icon != null)
                {
                    int n = r.Next(kartinki.Count);
                    icon.Text = kartinki[n];
                    icon.ForeColor = icon.BackColor;
                    kartinki.RemoveAt(n);
                }
            }
        }
        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
           
        }
        private void label1_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled == true)
                return;
            Label clickLabel = sender as Label;
            if (clickLabel != null)
            {
                if (clickLabel.ForeColor == Color.Black)
                    return;
                if (Click1 == null)
                {
                    Click1 = clickLabel;
                    Click1.ForeColor = Color.Black;

                    return;
                }
                Click2 = clickLabel;
                Click2.ForeColor = Color.Black;
                CheckForWinner();
                if (Click1.Text == Click2.Text)
                {
                    Click1 = null;
                    Click2 = null;
                    return;
                }
               
                timer1.Start();
            }
        }
        Label Click1 = null;
        Label Click2 = null;
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            Click1.ForeColor = Click1.BackColor;
            Click2.ForeColor = Click2.BackColor;
            Click1 = null;
            Click2= null;
        }
        private void CheckForWinner()
        {
            foreach (Control control in tableLayoutPanel1.Controls)
            {
                Label icon = control as Label;

                if (icon != null)
                {
                    if (icon.ForeColor == icon.BackColor)
                        return;
                }
            }

            MessageBox.Show("Вы выиграли!", "Поздравляю");
            Close();
        }
    }
        
}
