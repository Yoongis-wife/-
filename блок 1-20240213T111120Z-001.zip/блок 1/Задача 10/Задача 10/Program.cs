﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //В цикле вводятся 8 чисел, определить, встречались ли среди них числа, больше 4? Если
            // встречались вывести сообщение «Да, встречались», иначе «Нет, не встречались».
            int x = 0;
            int yes = 0;
           for (int i=1;i<9;i++)
            {
                Console.WriteLine("Введите "+ i+ " число");
                x=int.Parse(Console.ReadLine());
                if (x>4) yes++;
            }
            if (yes>0)
                Console.WriteLine("Среди введеных чисел встречались числа больше 4");
            else Console.WriteLine("Нет, не встречались");
            Console.ReadKey();
        }
    }
}
