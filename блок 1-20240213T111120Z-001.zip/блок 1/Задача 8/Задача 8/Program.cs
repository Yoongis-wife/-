﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //В цикле вводится N чисел найти максимальное и вывести его на экран.
            Console.WriteLine("Введите кол-во чисел");
            int n=int.Parse(Console.ReadLine());
            int x = 0;
            int max = -10000;
            for (int i=1; i<= n; i++)
            {
                Console.WriteLine("Введите  "+i+" число");
                x=int.Parse(Console.ReadLine());
                if (x>max) max=x;
            }
            Console.WriteLine("Максимальное число равно "+max);
            Console.ReadLine();
        }
    }
}
