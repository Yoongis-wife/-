﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_14
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Найти сумму всех элементов последовательности, An=корень nn+1/5n, n=10
            double sum = 0;
            double a = 0;
            int n = 10;
            for (int i=1; i<=n; i++)
            {
                a=(Math.Sqrt(n*n+1))/5*n;
                sum+=a;
            }
            Console.WriteLine("Сумма всех элементов последовательности {0:N2}",sum);
            Console.ReadLine();
        }
    }
}
