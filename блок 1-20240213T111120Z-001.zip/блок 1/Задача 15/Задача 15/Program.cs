﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_15
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Написать программу, которая выводит таблицу сложения первых десяти целых
            //положительных чисел.
            
            Console.WriteLine("Таблица сложения");
            for (int n = 1; n<11; n++)
            {
                for (int i = 1; i<11; i++)
                {
                    Console.WriteLine(n+"+"+i+"="+(i+n));
                    
                }
                Console.WriteLine("\n");
            }
            Console.ReadLine();
        }
    }
}
