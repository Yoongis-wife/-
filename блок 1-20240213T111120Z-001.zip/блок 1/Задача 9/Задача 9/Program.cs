﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //В цикле вводится N чисел посчитать количество четных чисел.
            Console.WriteLine("Введите кол-во чисел");
            int n=int.Parse(Console.ReadLine());
            int x = 0;
            int col = 0;
            for (int i = 1; i <=n; i++)
            {
                Console.WriteLine("Введите "+i+" число");
                x=int.Parse(Console.ReadLine());
                if (x%2==0) col++;
            }
            Console.WriteLine("Количество четных чисел равно "+col);
            Console.ReadKey();
        }
    }
}
