﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Банк начисляет 5% годовых. Выведите на экран, какой станет сумма вклада S, положенная на
            //N лет.
            Console.WriteLine("Введите положенную сумму");
             double sum = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите количестов лет");
            double N = int.Parse(Console.ReadLine());
            double s = 0;
            double S = 0;
            for (int i = 1; i <= N; i++)
            {
                s = (sum*5/100);
                S+=s;
            }
            sum+=S;
            Console.WriteLine("По истечению "+N+" лет, сумма вклада станет {0:F2} рублей",sum);
            Console.ReadLine();
        }
    }
}
