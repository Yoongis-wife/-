﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Найти произведение всех элементов последовательности An=3n/5nn+1, n=10
            double a = 0;
            double pr = 1;
            int n = 10;
            for (int i=1; i<=n; i++)
            {
                a=(3*i-2)/(5*i*i)+1;
                pr*=a;
            }
            Console.WriteLine("Произведение равно {0}", pr);
            Console.ReadLine();




        }
    }
}
