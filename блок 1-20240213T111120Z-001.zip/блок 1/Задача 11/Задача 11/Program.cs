﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задача_11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Начав тренировки , спортсмен в первый день пробежал 10 км. Каждый следующий день он
            //увеличивал дневную норму на 10% от нормы предыдущего дня.Какой суммарный путь
            //пробежал спортсмен за 7 дней ?
            double pday = 10;
            double sum = 0;
            double sday = 0;
           for (int i=1;i<=7; i++)
            {
                sday=(pday*10/100)+pday;
                sum+=pday;
                pday=sday;
            }
            Console.WriteLine("За 7 дней спортсмен пробежал "+sum+"км");
            Console.ReadLine();
        }
    }
}
