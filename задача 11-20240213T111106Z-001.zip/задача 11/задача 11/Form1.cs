﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace задача_11
{
    public partial class Form1 : Form
    {
        public class GeometricFigure
        {
            public int CoordinatX { get; set; }
            public int CoordinatY { get; set; }
            public GeometricFigure (int x,int y)
            {
                CoordinatX = x;
                CoordinatY = y;
            }
        }
        public bool proverka;
        public class Triangle : GeometricFigure
        {
            public int St_A { get; set; }
            public int St_B { get; set; }
            public int St_C { get; set; }
           
            public Triangle(int a, int b, int c, int x, int y):base (x,y)
            {
                
                St_A = a;
                St_B = b;
                St_C = c;
                if (St_A + St_B < St_C)
                {
                   
                    var mc = new Form1();
                    mc.proverka = false;
                }
                else 
                {
                    var mc = new Form1();
                    mc.proverka = true; 
                }
                
            }
           
        }
        public class Circle:GeometricFigure
        {
            public int diam { get; set; }
            public Circle (int x,int y, int d):base (x,y)
            {
                diam = d;
                if (d>220 && d<=0) MessageBox.Show("Эта окружность слишком большая. Диаметр должен быть не более 220 и не меньше 0.");
                if((240-d < x) && (240 - d < y)) MessageBox.Show("Окружность не входит в поле зрения. Координаты точки нуно уменьшить");
            }

        }
        public Form1()
        {
            InitializeComponent();

           
        }
        public void DrawTriangle()
        {
            Triangle tr = new Triangle(Convert.ToInt32(textBox1.Text), Convert.ToInt32(textBox2.Text), Convert.ToInt32(textBox3.Text), 30, 30);

            Point[] points = new Point[3];
            points[0].X = 30; points[0].Y = 30;
            points[1].X = 20 + Convert.ToInt32(textBox1.Text); points[1].Y = 20;
            points[2].X = 20 + Convert.ToInt32(textBox2.Text); points[2].Y = 20 + Convert.ToInt32(textBox1.Text);
            Bitmap bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);

            using (Graphics grfx = Graphics.FromImage(bmp))
            {
                grfx.Clear(Color.White);
                grfx.DrawPolygon(Pens.Black, points);
            }
            pictureBox1.Image = bmp;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
          
        }

        private void label3_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Circle circle1 = new Circle(Convert.ToInt32(textBox4.Text), Convert.ToInt32(textBox5.Text), Convert.ToInt32(textBox6.Text));

            Graphics g = pictureBox2.CreateGraphics();
            g.Clear(Color.White);
            g.FillEllipse(Brushes.Black, circle1.CoordinatX, circle1.CoordinatY, circle1.diam, circle1.diam);


        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (proverka == true) { DrawTriangle(); }
            else if (proverka == false) { pictureBox1.Dispose(); MessageBox.Show("Такого треугольника нет"); }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pictureBox2.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pictureBox1.Dispose();
        }
    }
}
