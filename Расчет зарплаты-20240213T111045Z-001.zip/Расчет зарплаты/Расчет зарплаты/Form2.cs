﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Расчет_зарплаты
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            
        }
        public int a,b,c,n,v,f;
        double d;

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            Form1 frm1 = this.Owner as Form1;
            d = Convert.ToDouble(frm1.textBox2.Text);
            textBox2.Text= Convert.ToString(d*(a + b + (c * n * v)));
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Form1 frm1 = this.Owner as Form1;
            //Стаж
            if (frm1.comboBox1.SelectedIndex == 0) a = 0;
            if (frm1.comboBox1.SelectedIndex == 1) a = 2000;
            if (frm1.comboBox1.SelectedIndex == 2) a = 4000;
            //Разряд
            if (frm1.comboBox2.SelectedIndex == 0) b = 0;
            if (frm1.comboBox2.SelectedIndex == 1) b = 1000;
            if (frm1.comboBox2.SelectedIndex == 2) b = 2000;
            //1 час
            c = Convert.ToInt32(frm1.textBox1.Text);
            //раб. день длит
            if (frm1.radioButton4.Checked == true) n = 6;
            if (frm1.radioButton5.Checked == true) n = 8;
            //раб дней в месяце
            v = Convert.ToInt32(frm1.numericUpDown1);
            textBox1.Text = Convert.ToString((a + b + (c * n * v)));
        }
    }
}
