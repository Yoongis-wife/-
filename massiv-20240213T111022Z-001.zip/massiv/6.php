<?php 
$arr=array('1','2','3','4','5');
$elem="$";
$position=$_GET['pos'];
if (($position-1)<=count($arr))
{
    array_splice($arr,$position-1,0,$elem);
    echo implode($arr);
}
else
{
    echo "Позиция нового элемента должна быть меньше 7";
}


?>