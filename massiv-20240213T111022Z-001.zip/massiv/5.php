<?php 
$arrs=array();
for($i=0;$i<31;$i++)
{
    $arrs[$i]=rand(-15,25);
}
$sred=0;
$sum=0;
for($i=0;$i<31;$i++)
{
    $sum+=$arrs[$i];
}
$sred=$sum/count($arrs);
echo"Температура за месяц  ";
echo implode(" ",$arrs);
echo "<br>Средняя температура за месяц равна ".round($sred,2);
echo "<br>5 самых низких температур ";
asort($arrs, SORT_NUMERIC);
echo implode(" ",(array_slice($arrs, 0, 5, true)));
echo "<br>5 самых высоких температур ";
rsort($arrs, SORT_NUMERIC);
echo implode (" ",(array_slice($arrs, 0, 5, true)));




?>