<?php 
$arr=array();
for($i=0;$i<5;$i++)
{
    $arr[$i]=rand(1,10);
}
$sum=0;
for($i=0;$i<count($arr);$i++)
{
    $sum+=$arr[$i];
}
$srednee=$sum/count($arr);
echo "Среднее арифметическое равно ".$srednee;
?>