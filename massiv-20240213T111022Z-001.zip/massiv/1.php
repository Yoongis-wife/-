<?php 
$array=array(
    'Привет,',
    'мир',
    '!'
);
for($i=0;$i<count($array);$i++)
{
    echo $array[$i]." ";
}
?>