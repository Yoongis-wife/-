<?php 
$array=array(
    'Привет,',
    'мир',
    '!'
);
unset($array[0]);
array_unshift($array,"Здравствуй,");

for($i=0;$i<count($array);$i++)
{
    echo $array[$i]." ";
}
?>