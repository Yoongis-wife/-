<?php 
function maximum($x,$y)
{
    $max=0;
    if($x>=$y)
    {
        $max=$x;
    }
    else if($y>$x)
    {
        $max=$y;
    }
    echo"Исходные числа ".$x." ".$y."<br>";
    echo "Максимальное число ".$max."<br>";
    return $max;
}
$a=(maximum(2,5));
$b=(maximum(3,6));
maximum($a,$b);
?>