<?php
$st=$_GET['str'];
$arr=array();
$arr=explode(' ',$st);
$str=implode(' ',$arr);
echo "Значения в верхнем регистре ". strtoupper($str);
echo "<br>Значения в нижнем регистре ".strtolower($str);
?>