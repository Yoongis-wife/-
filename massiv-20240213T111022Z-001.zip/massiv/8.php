<?php 
$count=rand(3,20);
$array=array();
for($i=0;$i<$count;$i++)
{
    $array[$i]=rand(10,99);
}
echo "Массив из ".$count. " элементов, заполненный случайными чсилами. ". join(" ",$array). "<br>";
sort($array);
echo "Массив в отсортированном виде ";
echo implode(' ',$array)."<br>";
echo "Элементы массива в обратном порядке ";
echo implode(" ",array_reverse($array))."<br>";
echo "Массив после удаления последнего элемента ";
array_pop($array);
echo implode(" ",$array)."<br>";

$sum=0;
for($i=0;$i<count($array);$i++)
{
    $sum+=$array[$i];
}
echo "Сумма элементов массива ".$sum."<br>";
echo "Количество элементов в массиве ".count($array)."<br>";
echo "Среднее арифметическое для элементов массива ".$sum/count($array)."<br>";
if(in_array(50,$array))
{
    echo "Число 50 есть в массиве <br>";
}
else {echo "Числа 50 нет в массиве <br>";}
echo "Массив из уникальных значений ". implode(" ",array_unique($array));
?>