<?php 
$color = array ('white', 'green', 'red' );
asort($color, SORT_STRING);
echo implode(" ",$color);
?>